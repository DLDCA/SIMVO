clear;
close all;
clc;
addpath([pwd,'\SubFunctions']);

runs=3;                                                
partitionLevels=30;      % 6��10��20��30                              

Population_size=30;

ImageSize.width=768; 
ImageSize.height=768;

Iteration=0;
MaxFEs=2000;

evaluate_name={'PSNR','SSIM','FSIM'};

image_filename={'colonca1.jpeg','colonca2.jpeg'};
                                      
method={'SIMVO'};

obj_name={'renyi2d'};


image_files.name=[];
for i=1:size(image_filename,2)
    image_files(i).name=cell2mat(image_filename(i));
end

timestr=datestr(now,'mm-dd_HH_MM');
if size(method,2)==1
    obj_path=[pwd,'\exp_result\',method{1},'_Level',num2str(partitionLevels),'_result-set_' timestr];  
else
    obj_path=[pwd,'\exp_result\',method{1},'_',method{2},'_Level',num2str(partitionLevels),'_result-set_' timestr];  
end

for obj=1:size(obj_name,2)
    objectiveFunction=obj_name{obj};
    dir_name=[obj_path,'\' objectiveFunction];           
    xlsxname=[dir_name,'\FES-',timestr,'.xlsx'];
    NumofRecord=40;
    measure1_name={'BDE','PRI','VOI','GCE'};
    measure2_name={'SSIM','FSIM','RMSE','MSE','PSNR','NCC','AD','SC','MD','NAE'};
    measure1_name=intersect(evaluate_name,measure1_name);
    measure2_name=intersect(evaluate_name,measure2_name);
    nLines = size(method,2);
    basic_linestyles = cellstr(char('-',':','-.','--'));
    basic_Markers    = cellstr(char('o','x','+','*','s','d','v','^','<','>','p','h','.'));
    MarkerEdgeColors = hsv(nLines);
    linestyles       = repmat(basic_linestyles,ceil(nLines/numel(basic_linestyles)),1);
    Markers          = repmat(basic_Markers,ceil(nLines/numel(basic_Markers)),1);

    for i=1:length(method)
        methodname=method{i};
        addpath([pwd '\opt_algorithm\' methodname]);
        pathName=[dir_name,'\',method{i},'_result-set' ]; 
        if ~exist('pathName','dir')
             mkdir(pathName);
        end
        disp(['*****************  ','Folds of ',method{i},' in ',objectiveFunction,'  *****************']);
        for im_len=1:length(image_filename)
            Find_res(i,im_len).fitness=-inf;
            Find_res(i,im_len).imgname={};
            Find_res(i,im_len).thresholds=[];
            Find_res(i,im_len).methodName=method{i};
            Find_res(i,im_len).run=0;
            Find_res(i,im_len).FEs=0;
            Find_res(i,im_len).Iter=0;
            Find_res(i,im_len).AvgTime=0;
        end
        parfor fold=1:runs
            disp(['Fold',num2str(fold)]);
            [fd_methodata,fd_xlsimagename,fd_cg_curves,fd_FEcount,fd_image_info]=callmain(methodname,pathName,partitionLevels,MaxFEs,Population_size,image_files,NumofRecord,objectiveFunction,ImageSize);
            fold_methodata(fold,:,:)=fd_methodata;
            fold_xlsimagename(fold,:)=fd_xlsimagename;
            fold_cg_curves(fold,:,:)=fd_cg_curves;
            fold_FEcount(fold,:)=fd_FEcount;
            fold_image_info(fold,:,:)=fd_image_info;         
        end
        for j=1:runs
            image_info(:,:)=fold_image_info(j,:,:);
            for im_sign=1:length(image_info)                 
                 % For mat
                 sampleLabels=image_info(im_sign).mat_sampleLabels;
                 superpixelLabels=image_info(im_sign).mat_superpixelLabels;
                 refImage=image_info(im_sign).mat_refImage;
                 dataFilename1=image_info(im_sign).mat_dataFilename1;
                 dataFilename2=image_info(im_sign).mat_dataFilename2;
                 save (dataFilename1, 'sampleLabels', 'superpixelLabels');
                 save (dataFilename2, 'refImage');
            end
            sheetname=strcat(methodname,'_',num2str(j),'run');            
            methodata(:,:)= fold_methodata(j,:,:);
            xlsimagename=fold_xlsimagename(j,:);
            cg_curves(:,:)=fold_cg_curves(j,:,:);
            FEcount=fold_FEcount(j,:);
            
            all_curves(i,j,:,:)=cg_curves; 
            xlsmethodata={};
            for l=1:size(methodata,2)-5
                xlsmethodata{1,l}=['gBest',num2str(l)];
            end
            xlsmethodata{1,size(methodata,2)-4}='gbestvalue';
            xlsmethodata{1,size(methodata,2)-3}='FEscount';
            xlsmethodata{1,size(methodata,2)-2}='etime';
            xlsmethodata{1,size(methodata,2)-1}='MaxFEs';
            xlsmethodata{1,size(methodata,2)}='Iteration';
            xlsimagename=xlsimagename';
            xlsmethodata=[xlsmethodata;methodata];
            xlswrite(xlsxname,xlsimagename,sheetname,'A2');
            xlswrite(xlsxname,xlsmethodata,sheetname,'B1');
            for im_sign=1:length(image_filename)
                Find_res(i,im_sign).AvgTime=Find_res(i,im_sign).AvgTime+methodata{im_sign,size(methodata,2)-2};
                if methodata{im_sign,size(methodata,2)-4}>Find_res(i,im_sign).fitness
                    Find_res(i,im_sign).fitness=methodata{im_sign,size(methodata,2)-4};
                    Find_res(i,im_sign).thresholds=cell2mat(methodata(im_sign,partitionLevels+1:size(methodata,2)-5));       
                    Find_res(i,im_sign).imgname{1}=image_filename{im_sign};
                    Find_res(i,im_sign).FEs=methodata{im_sign,size(methodata,2)-3};
                    Find_res(i,im_sign).Iter=methodata{im_sign,size(methodata,2)};
                    Find_res(i,im_sign).run=j;
                end
            end     
            
            if isempty(measure1_name)==0
                seg_measure1(sheetname,xlsxname,xlsimagename,pathName,image_files,measure1_name,ImageSize);
            end

            if isempty(measure2_name)==0
                seg_measure2(sheetname,xlsxname,xlsimagename,pathName,image_files,measure1_name,measure2_name); 
            end
            close all;
        end

        for im_sign=1:length(image_filename)
            image_info(:,:)=fold_image_info(Find_res(i,im_sign).run,:,:);

            figure;  
            imshow(image_info(im_sign).gray);
            save_pic(image_info(im_sign).gray_filename);

            figure;
            imhist(image_info(im_sign).hist);
            save_pic(image_info(im_sign).hist_filename);

            figure;
            imshow(image_info(im_sign).NLM);
            save_pic(image_info(im_sign).NLM_filename);

            figure;
            mesh(image_info(im_sign).TwoD);
            save_pic(image_info(im_sign).TwoD_filename);

             figure;
             imshow(image_info(im_sign).seg_gray);
             save_pic(image_info(im_sign).seg_gray_filename);

             figure;
             imshow(image_info(im_sign).seg_color);
             save_pic(image_info(im_sign).seg_color_filename);

             figure;
             save_pic_seg(image_info(im_sign).seg,image_info(im_sign).seg_filename,image_info(im_sign).seg_gBest,image_info(im_sign).seg_level);
             close all;
        end
    end
           
    for im_sign=1:length(image_filename)
        for method_sign=1:length(method)
            xlsThData{method_sign+1,1}=Find_res(method_sign,im_sign).methodName;
            xlsThData{1,partitionLevels+2}='Fitness';
            xlsThData{1,partitionLevels+3}='FEs';
            xlsThData{1,partitionLevels+4}='Iter';
            xlsThData{1,partitionLevels+5}='AvgTime';
            for th_sign=1:partitionLevels
                xlsThData{1,th_sign+1}=['Thresh',num2str(th_sign)];
                xlsThData{method_sign+1,th_sign+1}=Find_res(method_sign,im_sign).thresholds(th_sign);      
            end
            xlsThData{method_sign+1,partitionLevels+2}=Find_res(method_sign,im_sign).fitness;
            xlsThData{method_sign+1,partitionLevels+3}=Find_res(method_sign,im_sign).FEs;
            xlsThData{method_sign+1,partitionLevels+4}=Find_res(method_sign,im_sign).Iter;
            xlsThData{method_sign+1,partitionLevels+5}=Find_res(method_sign,im_sign).AvgTime/runs;
        end
        Thresh_data=[dir_name,'\','Thresholds_data.xlsx'];
        Thresh_sheet=image_filename{im_sign};
        xlswrite(Thresh_data, xlsThData, Thresh_sheet);
    end    

    close all;

end

