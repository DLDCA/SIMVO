function [methodata,xlsimagename,cg_curves,FEcount,image_info]=callmain(methodname,pathName,partitionLevels,MaxFEs,Population_size,image_files,NumofRecord,objectiveFunction,ImageSize)
    NORMALIZE_IMAGE = true;
    method=methodname;
    methodata=[];

    filePath = 'colon_aca/'; 
    directoryFiles = image_files; 
    it=1;
    for i=1:length(directoryFiles)
        xlscurrentFilename = directoryFiles(i).name;            
        if (length(xlscurrentFilename)>4)
            xlsimagename{it}=xlscurrentFilename;
            it=it+1;
        end    
    end
    
    im_sign=1;
    for fileIndex=1:length(directoryFiles)
        currentFilename = directoryFiles(fileIndex).name;
        if(length(currentFilename)>4) 

            flag=[];
            sign=0;
            while ~strcmp(flag,'.') 
                flag=currentFilename(end-sign); 
                sign=sign+1;
            end
            
            
            imageName = currentFilename(1:end-sign);
            dataFilename1 = [pathName '\' imageName '.mat'];
            
            dataFilename2_path=[pwd '\BW_dataset'];
            if exist(dataFilename2_path,'dir')==0
                 mkdir(dataFilename2_path);
            end
            
            dataFilename2 = [dataFilename2_path '\' imageName '.mat'];
            imageFullPath = [filePath currentFilename];
            image = imread(imageFullPath);
            if ~isempty(whos('image'))
                [imageX,imageY,imageDepth] = size(image);
                if NORMALIZE_IMAGE
                    width=ImageSize.width;
                    height=ImageSize.height;
                    if imageX>=imageY
                        image = imresize(image,[width,height]);
                    else
                        image = imresize(image,[height,width]);
                    end

                    

                end
                %% Convert to GreyScale
                if (imageDepth==3)
                    image=rgb2gray(image);
                end
                
                filename=[[pathName '\'],[currentFilename(1:end-sign) '_gray']];
                
                image_info(im_sign).gray=image;
                image_info(im_sign).gray_filename=filename;
                
                filename=[[pathName '\'],[currentFilename(1:end-sign) '_hist']];
                
                image_info(im_sign).hist=image;
                image_info(im_sign).hist_filename=filename;
                
                
                %% Compute the non-local means (NLM) of an image
                refImage=image;
                I=image;
                number_of_levels=partitionLevels+1; 
                level=partitionLevels;
                [m,n]=size(I);
                a=I;
                a0=im2double(a);
                t = 7;
                f = 2;
                a3=nlmeans(a0,t,f);

                filename=[[pathName '\'],[currentFilename(1:end-sign) '_NLM']];
                image_info(im_sign).NLM=a3;
                image_info(im_sign).NLM_filename=filename;
               
                for i=1:m
                    for j=1:n
                        a4(i,j)=a3(i,j);
                    end
                end
                a4 = (a4 - min(a4(:))) / (max(a4(:)) - min(a4(:)));
                a4 = im2uint8(a4);
                [m,n]=size(a);
                a0=(a);
                fxy=zeros(256,256);
                for i=1:m
                    for j=1:n
                        c=a0(i,j);
                        d=(a4(i,j));
                        fxy(c+1,d+1)=fxy(c+1,d+1)+1;
                    end
                end
                Pxy=fxy/m/n;
                %% Display the 2D-histogram

                filename=[[pathName '\'],[currentFilename(1:end-sign) '_2D']];
                image_info(im_sign).TwoD=Pxy;
                image_info(im_sign).TwoD_filename=filename;
                
                
                
                Lmax1=254;
                if size(I,3)==1 
                    mainename=['maine' method];
                    mainename=str2func(mainename(1,:));
                    [gBest,gbestvalue,FEcount,etime,MaxFEs,Convergence_curve,iter]=mainename(Lmax1,level,Pxy,MaxFEs,Population_size,objectiveFunction);
                   %% return optimal intensity
                    intensity=round(gBest);     
                   %% return fitness value
                    fitness=gbestvalue;    
                end
                Thresholds=intensity((number_of_levels):end);
                srtThr=sort(Thresholds);
                Thresholds = srtThr;
          
                v=find(diff(srtThr)==0);
                while (size(v,2) > 0)           
                    if size(I,3)==1
                        [gBest,gbestvalue,FEcount,etime,MaxFEs,Convergence_curve,iter]=mainename(Lmax1,level,Pxy,MaxFEs,Population_size,objectiveFunction);

                        intensity=round(gBest);     
                        fitness=gbestvalue;  
                    end
                    Thresholds=intensity((number_of_levels):end);
                    srtThr=sort(Thresholds);
                    Thresholds = srtThr;
                    v=find(diff(srtThr)==0);
                end           
                 X = imageGRAY(I,Thresholds);

                 filename=[[pathName '\'],[currentFilename(1:end-sign) '_seg_gray']];
                 image_info(im_sign).seg_gray=X;
                 image_info(im_sign).seg_gray_filename=filename;
                 
                 
                 
                 X1=X;
                 X1=double(X1); 
                 X = imquantize(I,Thresholds);
                 Y=label2rgb(X);
                filename=[[pathName '\'],[currentFilename(1:end-sign) '_seg_color']];
                
                 image_info(im_sign).seg_color=Y;
                 image_info(im_sign).seg_color_filename=filename;
                 
                 filename=[[pathName '\'],[currentFilename(1:end-sign) '_seg']];  
                 image_info(im_sign).seg=image;
                 image_info(im_sign).seg_filename=filename;
                 image_info(im_sign).seg_level=level;
                 image_info(im_sign).seg_gBest=gBest;
               %% Post-Processing steps
                for l=1:2*level
                    outdata{1,l}=gBest(l);
                end       
                outdata{1,2*level+1}=gbestvalue;
                outdata{1,2*level+2}=FEcount;
                outdata{1,2*level+3}=etime;
                outdata{1,2*level+4}=MaxFEs;
                outdata{1,2*level+5}=iter;  
                methodata=[methodata; outdata];
                cg_curves(fileIndex,:)=MySampling(Convergence_curve,NumofRecord);
                sampleLabels=X;
                superpixelLabels=X1;
                
                 image_info(im_sign).mat_sampleLabels=sampleLabels;
                 image_info(im_sign).mat_superpixelLabels=superpixelLabels;
                 image_info(im_sign).mat_refImage=refImage;
                 image_info(im_sign).mat_dataFilename1=dataFilename1;
                 image_info(im_sign).mat_dataFilename2=dataFilename2;
                 im_sign=im_sign+1;
                 clearvars -except im_sign image_info FEcount ImageSize objectiveFunction cg_curves NumofRecord refImage dataFilename2 Population_size MaxFEs partitionLevels xlsimagename method X1 X J dataFilename1 filePath directoryFiles pathName fileIndex NORMALIZE_IMAGE methodata;
            end
        end
    end
end

