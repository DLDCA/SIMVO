function  pBest_ind = LearnIndex_BLRIME(pfit,popsize,D,i)
% Biogeography-based exemplar generation method

[~,sort_index] = sort(pfit, 'ascend');
index = sort_index -1;

mu1 = (1 - index./sort_index);  %change
lambda1 = index./sort_index;  %change
pBest_ind = zeros(1,D);

for k = 1:D
    if rand <  lambda1(i)  %  Should we immigrate?
        % Yes - Pick a solution from which to emigrate (roulette wheel selection)
        RandomNum = rand * sum(mu1);
        Select = mu1(1);  
        SelectIndex = 1;
        while (RandomNum > Select) && (SelectIndex < popsize)
            SelectIndex = SelectIndex + 1;
            Select = Select + mu1(SelectIndex);
        end
        pBest_ind(k) =  SelectIndex; 
    else
        pBest_ind(k) = i;
    end 
end

if all(pBest_ind == i)    
    ind = randi(popsize);
    while ind==i, ind = randi(popsize);  end
    pBest_ind(randi(D)) = ind; 
end