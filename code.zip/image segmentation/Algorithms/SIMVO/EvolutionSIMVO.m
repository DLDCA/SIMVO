function [Fbest,Lbest,FE,MaxFEs,Convergence_curve,iter]=EvolutionSIMVO(fname,N,thdim,lb,ub,MaxFEs,Pxy)

dim=thdim/2;
Fbest=-inf;
%Two variables for saving the position and inflation rate (fitness) of the best universe
Best_universe=zeros(1,2*dim);
Best_universe_Inflation_rate=-inf;

%Initialize the positions of universes
Universes=random_initialization(N,dim,ub,lb);
%Inflation rates (I) (fitness values)
Inflation_rates=zeros(1,size(Universes,1));
%Minimum and maximum of Wormhole Existence Probability (min and max in
% Eq.(3.3) in the paper
WEP_Max=1;
WEP_Min=0.2;
FEs=0;
Convergence_curve=[];
for i=1:size(Universes,1)
    
    %Boundary checking (to bring back the universes inside search
    % space if they go beyoud the boundaries
    Flag4ub=Universes(i,:)>ub;
    Flag4lb=Universes(i,:)<lb;
    Universes(i,:)=(Universes(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
    
    %Calculate the inflation rate (fitness) of universes
%     Inflation_rates(1,i)=fobj(Universes(i,:));
%     FEs=FEs+1;
    [Inflation_rates(1,i),FEs,Universes(i,:)] =sigle_evaluation(Universes(i,:),dim,thdim,fname,Pxy,FEs); 
    %Elitism
    if Inflation_rates(1,i)>Best_universe_Inflation_rate
        Best_universe_Inflation_rate=Inflation_rates(1,i);
        Best_universe=Universes(i,:);
    end
    
end
%Iteration(time) counter
it=1;

%Main loop
while  FEs < MaxFEs
    
    %Eq. (3.3) in the paper
    WEP=WEP_Min+FEs*((WEP_Max-WEP_Min)/MaxFEs);
    
    %Travelling Distance Rate (Formula): Eq. (3.4) in the paper
    TDR=1-((FEs)^(1/6)/(MaxFEs)^(1/6));
    [sorted_Inflation_rates,sorted_indexes]=sort(Inflation_rates,'descend');
    
    for newindex=1:N
        Sorted_universes(newindex,:)=Universes(sorted_indexes(newindex),:);
    end
    
    %Normaized inflation rates (NI in Eq. (3.1) in the paper)
    normalized_sorted_Inflation_rates=normr(sorted_Inflation_rates);    
    Universes(1,:)= Sorted_universes(1,:);
    New_Universes = Universes;
    %Update the Position of universes
    for i=2:size(Universes,1)%Starting from 2 since the firt one is the elite
        Back_hole_index=i;
        if rand < 0.5
            for j=1:size(Universes,2)
                r1=rand();
                if r1<normalized_sorted_Inflation_rates(i)
                    White_hole_index=RouletteWheelSelection(-sorted_Inflation_rates);
                    if White_hole_index==-1
                        White_hole_index=1;
                    end
                    %Eq. (3.1) in the paper
                    New_Universes(Back_hole_index,j)=Sorted_universes(White_hole_index,j);
                end
                %different for each variables
                r2=rand();
                if r2<WEP
                    r3=rand();
                    if r3<0.5
                        New_Universes(i,j)=Best_universe(1,j)+TDR*((ub(j)-lb(j))*rand+lb(j));
                    else
                        New_Universes(i,j)=Best_universe(1,j)-TDR*((ub(j)-lb(j))*rand+lb(j));
                    end
                end
            end
        else
            %%  Information sharing search
            J = 1/3;
            alpha = 0.5;
            p = rand;
            indexJ = randi(N);
            if p<J
                New_Universes(i,:) = Universes(i,:) +0.01.*(Universes(indexJ,:).*Levy(2*dim) - Universes(i,:));
            elseif p<(1-J)
                New_Universes(i,:) = Universes(i,:) + alpha.*(Universes(indexJ,:) - Universes(i,:).*Levy(2*dim));
            else
                New_Universes(i,:) = Universes(i,:) + alpha.*(Universes(indexJ,:) - Universes(i,:)).*Levy(2*dim);
            end
        end
        Flag4ub=New_Universes(i,:)>ub;
        Flag4lb=New_Universes(i,:)<lb;
        New_Universes(i,:)=(New_Universes(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
%         F_New_Universes_i = fobj(New_Universes(i,:));
%         FEs = FEs+1;
        [F_New_Universes_i,FEs,New_Universes(i,:)] =sigle_evaluation(New_Universes(i,:),dim,thdim,fname,Pxy,FEs); 
        if F_New_Universes_i > Inflation_rates(1,i)
            Universes(i,:) = New_Universes(i,:);
            Inflation_rates(1,i) = F_New_Universes_i;
        else
            %% Spiraling communication and collaboration (SCC) strategy
            Newpop1 = Universes;
            N = size(Universes,1);
%             dim = size(Universes,2);
            if i==1
                Communication_X = bestPositions;
            else
                Communication_X = Newpop1(i-1,:);
            end
            for j = 1:2*dim
                rand_index = floor(N*rand()+1);
                EG = mean(Universes(1:rand_index,j)); 
                if rand < FEs/MaxFEs
                    distance = abs(Best_universe(1,j)-Newpop1(i,j));
                    b=1;
                    a=-1+FEs*((-1)/MaxFEs);
                    t1=(a-1)*rand+1;
                    Newpop1(i,j)=distance*exp(b.*t1).*cos(t1.*2*pi)+Newpop1(i,j);
                end
                if  rand > Inflation_rates(1,i)/sum(Inflation_rates)    
                    r=rand();
                    Collaboration_X = r*Newpop1(i,j)+(1-r)*(EG);
                    Newpop1(i,j) = Collaboration_X + (rand-0.5)*2*(Communication_X(1,j)-Newpop1(i,j));
                else
                    r=rand();
                    IndivRand = rand()*(ub(j)-lb(j))+lb(j); 
                    Collaboration_X = r*IndivRand + (1-r)*(EG);
                    Newpop1(i,j) = Collaboration_X + (rand-0.5)*2*(Communication_X(1,j)-Newpop1(i,j));
                end  
            end 
            % 控制越界值
            Flag4ub=Newpop1(i,:)>ub;
            Flag4lb=Newpop1(i,:)<lb;
            Newpop1(i,:)=(Newpop1(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
            % Evaluation
%             F_Newpop1_i = fobj(Newpop1(i,:)); 
%             FEs=FEs+1;
            [F_Newpop1_i,FEs,Newpop1(i,:)] =sigle_evaluation(Newpop1(i,:),dim,thdim,fname,Pxy,FEs); 
            if F_Newpop1_i > Inflation_rates(1,i)
                Universes(i,:) = Newpop1(i,:);
                Inflation_rates(1,i) = F_Newpop1_i;
            end
        end
        if Inflation_rates(1,i) > Best_universe_Inflation_rate
            Best_universe = Universes(i,:);
            Best_universe_Inflation_rate = Inflation_rates(1,i);
        end
    end
    
    %Update the convergence curve
    Convergence_curve(it)=Best_universe_Inflation_rate;
    if Fbest<Best_universe_Inflation_rate
        FE=FEs;
        iter=it;
    end
    Fbest=Best_universe_Inflation_rate;
    Lbest=Best_universe;
    it=it+1;
end
end


function L=Levy(d)
beta=1.5;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
u=randn(1,d)*sigma;
v=randn(1,d);
step=u./abs(v).^(1/beta);
L=0.01*step;
end
