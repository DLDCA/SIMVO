function [Fbest,Lbest,FE,MaxFEs,Convergence_curve,iter]=EvolutionMDE( fname,SearchAgents_no,thdim,lb,ub,MaxFEs,Pxy)

dim=thdim/2;
Fbest=-inf;

para=[SearchAgents_no,MaxFEs,0.2,0.8,0.2];
%% 
nPop=para(1); 
MaxIt=para(2); 
nVar=2*dim; 
VarSize=[1,2*dim]; 
beta_min=para(3); 
beta_max=para(4); 
pCR=para(5); 
lb=ones(1,2*dim).*lb; 
ub=ones(1,2*dim).*ub; 
%% Initialization
FEs=0;
empty_individual.Position=[]; 
empty_individual.Cost=[]; 
BestSol.Cost=-inf; 

pop=repmat(empty_individual,nPop,1); 
pop1 = random_initialization(nPop,dim,ub,lb);
for i=1:nPop 
    pop(i).Position=pop1(i,:);
   if FEs < MaxIt
       [pop(i).Cost,FEs,pop(i).Position] =sigle_evaluation(pop(i).Position,dim,thdim,fname,Pxy,FEs);   

   else
       break
   end
    if pop(i).Cost>BestSol.Cost 
        BestSol=pop(i); 
    end    
end
BestCost=zeros(MaxIt,1); 
Convergence_curve=[];
it=1;
z1=0.03; 
%%  Main Loop
while FEs<MaxIt 
    for i=1:nPop 
        x=pop(i).Position; 

        A=randperm(nPop); 
        A(A==i)=[]; 
        a=A(1);
        b=A(2);
        c=A(3);
        %  Mutation
        beta=unifrnd(beta_min,beta_max,VarSize); 
        y=pop(a).Position+beta.*(pop(b).Position-pop(c).Position); 

        y=max(y,lb);
		y=min(y,ub);
        % Crossover
        z=zeros(size(x)); 
        j0=randi([1,numel(x)]);
        for j=1:numel(x) 
            if j==j0 || rand<=pCR 
                z(j)=y(j);
            else
                z(j)=x(j); 
            end
        end
       NewSol.Position=z; 
       [NewSol.Cost,FEs,NewSol.Position] =sigle_evaluation(NewSol.Position,dim,thdim,fname,Pxy,FEs);          
        if NewSol.Cost>pop(i).Cost
            pop(i)=NewSol; 
            if pop(i).Cost>BestSol.Cost 
               BestSol=pop(i);
            end
         end
    end 
    
    for po=1:nPop
        X(po,:)=pop(po).Position;
        AllFitness(po)=pop(po).Cost;
    end

    [X]=Fun_SMA(nPop,X,AllFitness,MaxFEs,FEs,lb,ub,2*dim,BestSol.Position,BestSol.Cost,z1);
    
    for po=1:nPop
        Flag4ub=X(po,:)>ub;     
		Flag4lb=X(po,:)<lb;
		X(po,:)=(X(po,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb; 
        [temp_fit,FEs,X(po,:)] =sigle_evaluation(X(po,:),dim,thdim,fname,Pxy,FEs); 

        if temp_fit>pop(po).Cost
            pop(po).Position=X(po,:);
            pop(po).Cost=temp_fit;
        end
        if temp_fit>BestSol.Cost

            BestSol.Position=X(po,:);
            BestSol.Cost=temp_fit;
        end
    end  
    
    BestCost(it)=BestSol.Cost;  
    Convergence_curve(it)=BestSol.Cost;
 
    if Fbest<BestSol.Cost
        FE=FEs;
        iter=it;
    end
    Fbest=BestSol.Cost;
    Lbest=BestSol.Position;
    it=it+1;
end
end
