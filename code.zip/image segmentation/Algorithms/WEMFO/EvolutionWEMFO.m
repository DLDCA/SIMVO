function [Fbest,Lbest,FE,MaxFEs,Convergence_curve,iter]=EvolutionWEMFO(fname,N,thdim,lb,ub,MaxFEs,Pxy)

dim=thdim/2;
Fbest=-inf;

Moth_pos=random_initialization(N,dim,ub,lb);
Convergence_curve=zeros(1,MaxFEs);
it=1;
Convergence_curve=[];
FEs=0;
s=0;
while  FEs < MaxFEs 
    Flame_no=round(N-FEs*((N-1)/MaxFEs));
                                                         

    for i=1:size(Moth_pos,1)
        Flag4ub=Moth_pos(i,:)>ub;
        Flag4lb=Moth_pos(i,:)<lb;
        Moth_pos(i,:)=(Moth_pos(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;  
        if FEs<MaxFEs
 
            [Moth_fitness(1,i),FEs,Moth_pos(i,:)] =sigle_evaluation(Moth_pos(i,:),dim,thdim,fname,Pxy,FEs);
        else
            break;
            
        end    
        
    end

    if it==1
        [fitness_sorted I]=sort(Moth_fitness,'descend');
        sorted_population=Moth_pos(I,:);
        
        % Update the flames% 
        best_flames=sorted_population;
        best_flame_fitness=fitness_sorted;   
        Best_flame_score=fitness_sorted(1);
        
    else  
        double_population=[previous_population;best_flames];%previous_population
        double_fitness=[previous_fitness best_flame_fitness];
        
        [double_fitness_sorted I]=sort(double_fitness,'descend');
        double_sorted_population=double_population(I,:);
        
        fitness_sorted=double_fitness_sorted(1:N);
        sorted_population=double_sorted_population(1:N,:);
        
        % Update the flames
        best_flames=sorted_population;
        best_flame_fitness=fitness_sorted;
        Best_flame_score=fitness_sorted(1);
    end
    

    BB=Best_flame_score;
    Best_flame_pos=sorted_population(1,:);
      
    previous_population=Moth_pos;
    previous_fitness=Moth_fitness;
    
    if BB>fitness_sorted(1)
        s=s/2;%qiao
    end   
    s=s+1;%qiao
    

    w1=(1-FEs/MaxFEs)^(1-tan(pi*(rand-0.5))*s/MaxFEs);  
    w2=(2-2*FEs/MaxFEs)^(1-tan(pi*(rand-0.5))*s/MaxFEs);  
    a1=2-FEs*((2)/MaxFEs); 
    a=-1+FEs*((-1)/MaxFEs);
    

    for i=1:size(Moth_pos,1) 
        for j=1:size(Moth_pos,2)
            if i<=Flame_no 
                distance_to_flame=abs(sorted_population(i,j)-Moth_pos(i,j));
                b=1;
                t=(a-1)*rand+1;
                

                if(FEs/MaxFEs>0.5)
                    Moth_pos(i,j)=distance_to_flame*exp(b.*t).*cos(t.*2*pi)+w2*sorted_population(i,j);
                else
                    Moth_pos(i,j)=w1*distance_to_flame*exp(b.*t).*cos(t.*2*pi)+sorted_population(i,j);
                end
            end
            
            if i>Flame_no 
                distance_to_flame=abs(sorted_population(i,j)-Moth_pos(i,j));
                b=1;
                t=(a-1)*rand+1;
                
                 if(FEs/MaxFEs>0.5)
                     Moth_pos(i,j)=w2*distance_to_flame*exp(b.*t).*cos(t.*2*pi)+sorted_population(Flame_no,j);
                 else
                    Moth_pos(i,j)=distance_to_flame*exp(b.*t).*cos(t.*2*pi)+w1*sorted_population(Flame_no,j);
                 end
            end
            
        end
        
    end

    Convergence_curve(it)=Best_flame_score;
    if Fbest<Best_flame_score
        FE=FEs;
        iter=it;
    end
    Fbest=Best_flame_score;
    Lbest=Best_flame_pos;
    it=it+1; 
end





