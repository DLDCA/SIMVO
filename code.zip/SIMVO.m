
function [Best_universe,Best_universe_Inflation_rate] = SIMVO(dim,MaxFEs,lb,ub,Universes, N, ObjFunc_ID, fhd)

Best_universe=zeros(1,dim);
Best_universe_Inflation_rate=inf;
Inflation_rates=zeros(1,size(Universes,1));
WEP_Max=1;
WEP_Min=0.2;
FEs=0;
for i=1:size(Universes,1)

    Inflation_rates(1,i) = fhd(Universes(i, :)', ObjFunc_ID);
    FEs=FEs+1;
    %Elitism
    if Inflation_rates(1,i)<Best_universe_Inflation_rate
        Best_universe_Inflation_rate=Inflation_rates(1,i);
        Best_universe=Universes(i,:);
    end
    
end

while FEs<=MaxFEs
    
     WEP=WEP_Min+FEs*((WEP_Max-WEP_Min)/MaxFEs);
    TDR=1-((FEs)^(1/6)/(MaxFEs)^(1/6));
    [sorted_Inflation_rates,sorted_indexes]=sort(Inflation_rates);
    
    for newindex=1:N
        Sorted_universes(newindex,:)=Universes(sorted_indexes(newindex),:);
    end
    
    normalized_sorted_Inflation_rates=normr(sorted_Inflation_rates);    
    Universes(1,:)= Sorted_universes(1,:);
    New_Universes = Universes;
    for i=2:size(Universes,1)
        Back_hole_index=i;
        if rand < 0.5
            for j=1:size(Universes,2)
                r1=rand();
                if r1<normalized_sorted_Inflation_rates(i)
                    White_hole_index=RouletteWheelSelection(-sorted_Inflation_rates);
                    if White_hole_index==-1
                        White_hole_index=1;
                    end
                    New_Universes(Back_hole_index,j)=Sorted_universes(White_hole_index,j);
                end
                r2=rand();
                if r2<WEP
                    r3=rand();
                    if r3<0.5
                        New_Universes(i,j)=Best_universe(1,j)+TDR*((ub(j)-lb(j))*rand+lb(j));
                    else
                        New_Universes(i,j)=Best_universe(1,j)-TDR*((ub(j)-lb(j))*rand+lb(j));
                    end
                end
            end
        else
            J = 1/3;
            alpha = 0.5;
            p = rand;
            indexJ = randi(N);
            if p<J
                New_Universes(i,:) = Universes(i,:) +0.01.*(Universes(indexJ,:).*Levy(dim) - Universes(i,:));
            elseif p<(1-J)
                New_Universes(i,:) = Universes(i,:) + alpha.*(Universes(indexJ,:) - Universes(i,:).*Levy(dim));
            else
                New_Universes(i,:) = Universes(i,:) + alpha.*(Universes(indexJ,:) - Universes(i,:)).*Levy(dim);
            end
        end
        Flag4ub=New_Universes(i,:)>ub;
        Flag4lb=New_Universes(i,:)<lb;
        New_Universes(i,:)=(New_Universes(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
        F_New_Universes_i = fhd(New_Universes(i, :)', ObjFunc_ID);
        FEs = FEs+1;
        if F_New_Universes_i < Inflation_rates(1,i)
            Universes(i,:) = New_Universes(i,:);
            Inflation_rates(1,i) = F_New_Universes_i;
        else
            Newpop1 = Universes;
            N = size(Universes,1);
            dim = size(Universes,2);
            if i==1
                Communication_X = Best_universe;
            else
                Communication_X = Newpop1(i-1,:);
            end
            for j = 1:dim
                rand_index = floor(N*rand()+1);
                EG = mean(Universes(1:rand_index,j)); 
                if rand < FEs/MaxFEs
                    distance = abs(Best_universe(1,j)-Newpop1(i,j));
                    b=1;
                    a=-1+FEs*((-1)/MaxFEs);
                    t1=(a-1)*rand+1;
                    Newpop1(i,j)=distance*exp(b.*t1).*cos(t1.*2*pi)+Newpop1(i,j);
                end
                if  rand > Inflation_rates(1,i)/sum(Inflation_rates)    
                    r=rand();
                    Collaboration_X = r*Newpop1(i,j)+(1-r)*(EG);
                    Newpop1(i,j) = Collaboration_X + (rand-0.5)*2*(Communication_X(1,j)-Newpop1(i,j));
                else
                    r=rand();
                    IndivRand = rand()*(ub(j)-lb(j))+lb(j); 
                    Collaboration_X = r*IndivRand + (1-r)*(EG);
                    Newpop1(i,j) = Collaboration_X + (rand-0.5)*2*(Communication_X(1,j)-Newpop1(i,j));
                end  
            end 
            Flag4ub=Newpop1(i,:)>ub;
            Flag4lb=Newpop1(i,:)<lb;
            Newpop1(i,:)=(Newpop1(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
            F_Newpop1_i = fhd(Newpop1(i, :)', ObjFunc_ID);
            FEs=FEs+1;
            if F_Newpop1_i < Inflation_rates(1,i)
                Universes(i,:) = Newpop1(i,:);
                Inflation_rates(1,i) = F_Newpop1_i;
            end
        end
        if Inflation_rates(1,i) < Best_universe_Inflation_rate
            Best_universe = Universes(i,:);
            Best_universe_Inflation_rate = Inflation_rates(1,i);
        end
    end
end
end


function L=Levy(d)
beta=1.5;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
u=randn(1,d)*sigma;
v=randn(1,d);
step=u./abs(v).^(1/beta);
L=0.01*step;
end
