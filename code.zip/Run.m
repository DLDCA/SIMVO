clc;
clear;

%% --------------------    Settings    -------------------------------- %%
% This section initializes the parameters
%% --------------------------------------------------------------------- %%
nPop = 30;                % Population size
dim = 30;                 % Number of decision variables
MaxFEs = dim * 10000;     % Maximum number of function evaluations
NumofExper = 30;          % Number of test runs
LB = -100;                % Lower bound
UB = 100;                 % Upper bound

% =========================================================================
global initial_flag;
initial_flag = 0;

% ========= CEC2017 =========
fhd = str2func('cec17_func');  % Use the CEC2017 function

% ============================== 
LB = LB * ones(1, dim);   % Adjust lower bound to match dimension
UB = UB * ones(1, dim);   % Adjust upper bound to match dimension

% Initialize population and cost arrays
Population = zeros(nPop, dim);
Cost = inf(1, nPop);      % Initialize with infinity

% ===================================================
for i = 1:NumofExper
    % This function (F2) has been deleted
    if i == 2 
        continue
    else
        rand('state', sum(100 * clock));  % Set random seed based on system clock
        initial_flag = 0;  % Reset initial_flag for each experiment
        Func_id = i;
        Function_name=['CEC17-F',num2str(i)];
        disp(['----------------',Function_name,'--------------------']);
        for j = 1:nPop
            Population(j, :) = LB + rand(1, dim) .* (UB - LB);  % Random initialization
            Cost(j) = feval(fhd,Population(j, :)',Func_id);      % Evaluate cost for each individual
        end
        %% Run the optimization algorithm (SIMVO)
        [BestSol,BestSolCost] = SIMVO(dim, MaxFEs, LB, UB, Population, nPop, Func_id, fhd);
    
        % Display the best cost for the current experiment
        disp(['BestSol: ', mat2str(BestSol)]);
        disp(['BestCost: ', num2str(BestSolCost) ]);
    end
end