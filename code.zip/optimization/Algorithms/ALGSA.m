function [Destination_fitness, Convergence_curve]=ALGSA(N,Max_iter,lb,ub,dim,fobj)

min_flag=1;
ElitistCheck=1;
Rpower=1;
limit=2;
p=0.5;
Rnorm=2;
FEs=0;
it=1;
AllFitness=inf*ones(N,1);
count_list = zeros(1,N);
success_list = zeros(1,N);
history_fitness = zeros(1,N);

X=initialization(N,dim,ub,lb);
Destination_fitness = inf;
Convergence_curve=[];
V=zeros(N,dim);
a = zeros(N,dim);

while FEs <  Max_iter
    
    for i=1:N
        Flag4ub=X(i,:)>ub;
        Flag4lb=X(i,:)<lb;
        X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
        AllFitness(i)=fobj(X(i,:));
        FEs=FEs+1;
    end
   
    if it == 1
        diff_fitness = zeros(1,N);
    else
        diff_fitness = history_fitness - AllFitness;
    end
 
    int = diff_fitness < 0;
    for l = 1 : N
        if int(l)
            count_list(l) = count_list(l) + 1;
            success_list(l) = 0;
        else
            count_list(l) = 0;
            success_list(l) = success_list(l) + 1;
        end
    end    
    [best, ~]=min(AllFitness);
    if best < Destination_fitness 
        Destination_fitness=best;
    end
    Convergence_curve(it) = Destination_fitness;
    it=it+1;
    [M]=massCalculation(AllFitness,min_flag);
    [G,count_list,success_list] = Gconstant(FEs,Max_iter,N,count_list,success_list,limit,p,a);
    a = Gfield(M,X,G,Rnorm,Rpower,ElitistCheck,FEs,Max_iter);
    [X,V]=move(X,a,V);
    history_fitness = AllFitness;
    
end
end

function [M]=massCalculation(fit,min_flag)
Fmax=max(fit);
Fmin=min(fit); 
[~, N]=size(fit);
if Fmax==Fmin
    M=ones(N,1);
else
    if min_flag==1 
        best=Fmin;worst=Fmax; 
    else 
        best=Fmax;worst=Fmin;
    end
    M=(fit-worst)./(best-worst); 
end
M=M./sum(M); 
end

function [G,count_list,success_list,ratio,G_flag] = Gconstant(FEs,Max_iter,N,count_list,success_list,limit,p,a)
alfa=20;G0=100;
G_flag = zeros(1,100);
G = zeros(N,1);
for i = 1:N
    G(i) = G0*exp(-alfa*FEs/Max_iter);
    
    int = count_list(i) > limit;
    suc = success_list(i) > limit;
    pro = rand < p;
    flag1 = suc & pro;
    flag = int & pro;
    
    
    temp_a = sqrt(sum(a(i,:).^2,2));
    if  temp_a == 0
        ratio = 1 / rand;
    else
        ratio = abs((log(G(i))-log(temp_a)));
    end
    if ratio < 1
        ratio = 1 / ratio;
    end
    
    if flag
        G(i) = G(i) .* ratio; 
        count_list(i) = 0;
        G_flag(i) = 1;
    end
    if flag1
        G(i) = G(i) .*ratio; 
        success_list(i) = 0;
        G_flag(i) = 2;
    end
    if G(i) > G0
        G(i)= G0;
    end 
end
end

function a=Gfield(M,X,G,Rnorm,Rpower,ElitistCheck,FEs,Max_iter)
[N,dim]=size(X);
final_per=1; 
if ElitistCheck==1
    kbest=final_per+(1-FEs/Max_iter)*(100-final_per);
    kbest=round(N*kbest/100);
else
    kbest=N;
end

[~, ds]=sort(M,'descend');
if size(ds)== 1
    ds=ones(N,1);
end

E = zeros(N,dim);
a = zeros(N,dim);
temp_G = 0;

for i=1:N
    for ii=1:kbest
        j=ds(ii);
        if j~=i
            R=norm(X(i,:)-X(j,:),Rnorm); 
            E(i,:) = E(i,:) + rand(1,dim).*(M(j)).*((X(j,:)-X(i,:))./(R^Rpower+eps));
            for k = 1:ii
                temp_G = temp_G + G(ds(k));
            end
            temp_G = temp_G / ii;
            zeros
            a(i,:) = a(i,:) + temp_G .* E(i,:);
            temp_G = 0;
        end
    end
end
end

function [X,V]=move(X,a,V)


[N,dim]=size(X);
V=rand(N,dim).*V+a; 
X=X+V; 
end