function [Destination_fitness, Convergence_curve]=KSO(N,MaxFEs,lb,ub,dim,fobj)
%%
X=initialization(N,dim,ub,lb);
a=zeros(1,dim);
Destination_fitness=inf;
bestPositions = ones(1,dim);
%%
FEs=0;
it=1;
jingdu=1e-3;
%%
while  FEs <= MaxFEs
    FEs = FEs+1000;
    for i=1:N
        F_i = fobj(X(i,:)); 
        FEs = FEs+1;
        x=[];
        tmpx = initialization(1,dim,ub,lb);
        for j=1:dim
            tmpxx = X(i,:);
            tmpxx(j) = tmpx(j);
            x=[x;tmpxx];
        end

        for ii=1:dim
            Flag4ub=x(ii,:)>ub;
            Flag4lb=x(ii,:)<lb;
            x(ii,:)=(x(ii,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
            x_All_Fitness(ii) = fobj(x(ii,:));
            FEs = FEs+1;
        end

        d=unidrnd(dim);
        xx=initialization(1,dim,ub,lb);
        temp=xx(d);
        xx=X(i,:);
        xx(d)=temp;
        xx_fitness=fobj(xx);
        FEs=FEs+1;

        All_X=[X(i,:);x;xx];
        All_fitness=[F_i x_All_Fitness xx_fitness];
        
        [min_fitness, index]=min(All_fitness);
        max_All_fitness =max(All_fitness);
        if min_fitness < Destination_fitness 
            Destination_fitness = min_fitness;
            bestPositions = All_X(index,:);
        end

        All_fitness=(exp(1)-1)*(All_fitness-min_fitness)/(max_All_fitness-min_fitness+eps)+1;
        sigma=(xx(d)-x(d,d))/(log(All_fitness(1)/All_fitness(dim+2))/(X(i,d)-xx(d)+eps)-log(All_fitness(1)/All_fitness(d+1))/(X(i,d)-x(d,d)+eps)+eps);
        for j=1:dim
            a(j)=-sigma*log(All_fitness(1)/All_fitness(j+1))/(X(i,j)-x(j,j)+eps)+X(i,j)+x(j,j);
            a(j)=a(j)/2;
            if sigma<0
                if(a(j)>=(ub+lb)/2) 
                    a(j)=lb;
                else
                a(j)=ub;
                end
            else
                if(a(j)<lb)
                    a(j)=lb;
                else
                    if(a(j)>ub)
                        a(j)=ub;
                    end
                end
            end
        end
        F_a = fobj(a);
        FEs=FEs+1;
        if F_a<= Destination_fitness 
           X(i,:) = a;
           Destination_fitness = F_a;
           bestPositions = a;
        else
           X(i,:)=bestPositions+(a-bestPositions).*rand(1,dim)*exp(FEs*log(jingdu)/(MaxFEs)); 
        end
        Flag4ub=X(i,:)>ub;
        Flag4lb=X(i,:)<lb;
        X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
    end
    Convergence_curve(it)=Destination_fitness;
    it=it+1;
end
end