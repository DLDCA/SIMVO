
function [Rabbit_Location, CNVG]=HHO(N,MaxFES,lb,ub,dim,fobj)

Rabbit_Location=zeros(1,dim);
Rabbit_Energy=inf;

X=initialization(N,dim,ub,lb);

CNVG=[];
fes=0;

t=0; 

while fes<MaxFES
    for i=1:size(X,1)
       
        FU=X(i,:)>ub;FL=X(i,:)<lb;X(i,:)=(X(i,:).*(~(FU+FL)))+ub.*FU+lb.*FL;
      
        fitness=fobj(X(i,:));
        fes=fes+1;
        
        if fitness<Rabbit_Energy
            Rabbit_Energy=fitness;
            Rabbit_Location=X(i,:);
        end
    end
    
    c=2*(1-(fes/MaxFES)); 
    for i=1:size(X,1)
        
        Escaping_Energy=c*(2*rand()-1); 
        
        if abs(Escaping_Energy)>=1
         
            r=rand();
            rand_Hawk_index = floor(N*rand()+1);
            X_rand = X(rand_Hawk_index, :);
            if r<0.5
              
                X(i,:)=X_rand-rand()*abs(X_rand-2*rand()*X(i,:));
            elseif r>0.5
                
                X(i,:)=(Rabbit_Location(1,:)-mean(X))-rand()*((ub-lb)*rand+lb);
            end
            
        elseif abs(Escaping_Energy)<1
           
            
            r=rand(); 
            
            if r>0.5 && abs(Escaping_Energy)<0.5 
                X(i,:)=(Rabbit_Location)-Escaping_Energy*abs(Rabbit_Location-X(i,:));
            end
            
            if r>0.5 && abs(Escaping_Energy)>0.5 
                Jump_strength=2*(1-rand()); 
                X(i,:)=(Rabbit_Location-X(i,:))-Escaping_Energy*abs(Jump_strength*Rabbit_Location-X(i,:));
            end
            
         
            if r<0.5 && abs(Escaping_Energy)>0.5, 
                
                Jump_strength=2*(1-rand());
                X1=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-X(i,:));
                
                fes=fes+2;
                if fobj(X1)<fobj(X(i,:)) 
                    X(i,:)=X1;
                else
                    X2=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-X(i,:))+rand(1,dim).*Levy(dim);
                    fes=fes+1;
                    if (fobj(X2)<fobj(X(i,:))), 
                        X(i,:)=X2;
                    end
                end
            end
            
            if r<0.5 && abs(Escaping_Energy)<0.5, 
                Jump_strength=2*(1-rand());
                X1=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-mean(X));
                
                fes=fes+2;
                if fobj(X1)<fobj(X(i,:)) 
                    X(i,:)=X1;
                else 
                    X2=Rabbit_Location-Escaping_Energy*abs(Jump_strength*Rabbit_Location-mean(X))+rand(1,dim).*Levy(dim);
                    fes=fes+1;
                    if (fobj(X2)<fobj(X(i,:))),
                        X(i,:)=X2;
                    end
                end
            end
            %%
        end
    end
    t=t+1;
    CNVG(t)=Rabbit_Energy;
    
end
toc
end

function o=Levy(d)
beta=1.5;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
u=randn(1,d)*sigma;v=randn(1,d);step=u./abs(v).^(1/beta);
o=step;
end