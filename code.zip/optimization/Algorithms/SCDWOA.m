function [Leader_pos,Convergence_curve]=SCDWOA(SearchAgents_no,MaxFEs,lb,ub,dim,fobj)

Leader_pos=zeros(1,dim);
Leader_score=inf; 
N = SearchAgents_no;
pBest_Cost=zeros(1,dim);
pBest_Posotions=zeros(N,dim);
for i=1:N
    pBest_Cost(i)=inf;
end

if size(lb) == 2
    Lb=lb*ones(1,dim);

    Ub=ub*ones(1,dim);
else
    Lb=lb;
    Ub=ub;
end

Positions=initialization(SearchAgents_no,dim,ub,lb);
Convergence_curve=[];
FEs=0;
it=1;

t = 0 : 1/(N-1):1;
t = 5.*t;
Pc = 0.0+(0.5-0.0).*(exp(t)-exp(t(1)))./(exp(t(N))-exp(t(1)));

gapm = 5;
stay_num = zeros(1,N); 
for i = 1:N
    pBest_ind(i,:) = LearnIndex_MVO(pBest_Cost,N,dim,i,Pc(i));  
end
AA=rand(1,N)+ones(1,N);      

for i=1:size(Positions,1)
    Flag4ub=Positions(i,:)>ub;
    Flag4lb=Positions(i,:)<lb;
    Positions(i,:)=(Positions(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
    FEs=FEs+1;
    fit=fobj(Positions(i,:));
    if fit<pBest_Cost(i)
        pBest_Cost(i)=fit;
        pBest_Posotions(i,:)=Positions(i,:);
        if fit< Leader_score
            Leader_score=fit; 
            Leader_pos=Positions(i,:);
        end
    end
    
end
type=2;

while  FEs < MaxFEs
    Flame_no=round(N-FEs*((N-1)/MaxFEs));
    a=2-FEs*((2)/MaxFEs);
    a2=-1+FEs*((-1)/MaxFEs);
    for i=1:size(Positions,1)
        r1=rand(); 
        r2=rand();
        
        A=2*a*r1-a; 
        C=2*r2;    
        b=1;
        
        l=(a2-1)*rand+1;  
        p = rand();       
    
            for j=1:size(Positions,2)
                
                if p<0.5
                    if abs(A)>=1
                        rand_leader_index = floor(SearchAgents_no*rand()+1);
                        X_rand = pBest_Posotions(rand_leader_index, :);
                        D_X_rand=abs(C*X_rand(j)-pBest_Posotions(i,j)); 
                        Positions(i,j)=X_rand(j)-A*D_X_rand;     
                    elseif abs(A)<1
                        D_Leader=abs(C*Leader_pos(j)-pBest_Posotions(i,j));
                        Positions(i,j)=Leader_pos(j)-A*D_Leader;      
                    end
                elseif p>=0.5
                     distance2Leader=abs(Leader_pos(j)-pBest_Posotions(i,j));
                    
                    Positions(i,j)=distance2Leader*exp(b.*l).*cos(l.*2*pi)+Leader_pos(j);
                 end
            end
    
        if rand()<0.03
            p = sobolset(dim);
            Positions(i,:)=lb+p(i,:).*(ub-lb);
        end
    end
    for i=1:size(Positions,1)
       Flag4ub=Positions(i,:)>ub;
        Flag4lb=Positions(i,:)<lb;
        Positions(i,:)=(Positions(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
        fit=fobj(Positions(i,:));
        FEs=FEs+1;
        if fit<pBest_Cost(i)
            pBest_Cost(i)=fit;
            pBest_Posotions(i,:)=Positions(i,:);
            if fit< Leader_score
                Leader_score=fit; 
                Leader_pos=Positions(i,:);
            end
        end
    end
   freq=0.4-(0.4-0)*FEs/MaxFEs;
   nest=pBest_Posotions(:,1:dim);
    K=rand(N,dim)>freq;
    stepsize=normrnd(0.1,0.5)*(nest(randperm(N),:)-nest(randperm(N),:));
    Positions=nest+stepsize.*K;
    for i=1:size(Positions,1)
        FEs = FEs + 1;
        fit1 = fobj(Positions(i,:));
        if fit1<pBest_Cost(i)
            pBest_Cost(i)=fit1;
            pBest_Posotions(i,:)=Positions(i,:);
            if fit1< Leader_score
                Leader_score=fit1;
                Leader_pos=Positions(i,:);
            end
        end
    end
   for i=1:N
        if stay_num(i)>gapm
            pBest_ind(i,:) = LearnIndex_MVO(pBest_Cost,N,dim,i,Pc(i)); 
            stay_num(i) = 0;
        end
        for  j=1:dim
            pBest_Universes(i,j) = pBest_Posotions(pBest_ind(i,j),j);  
        end
        [ k1,k2,k3 ] = GetRan3( i,N );
        T=pBest_Posotions(k1,:)+rand(1,dim).*(pBest_Posotions(k2,:)-pBest_Posotions(k3,:));
         Positions(i,:) = Leader_pos+ rand(1,dim).*(pBest_Universes(i,:)-T);    
        Inflation_rates=fobj(Positions(i,:));
        FEs=FEs+1;
        if Inflation_rates<pBest_Cost(i)
            pBest_Cost(i)=Inflation_rates;
            pBest_Posotions(i,:)=Positions(i,:);
            if Inflation_rates<Leader_score
                Leader_score=Inflation_rates;
                Leader_pos=Positions(i,:);
            end
        else
            stay_num(i) = stay_num(i)+1;  
        end
    end
    Convergence_curve(it)=Leader_score;
    it=it+1;
end
end
function o=Levy(dim)
beta=1.5;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
u=randn(1,dim)*sigma;v=randn(1,dim);step=u./abs(v).^(1/beta);
o=step;
end



