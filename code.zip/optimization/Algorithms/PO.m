
function [GBestX, Convergence_curve] = PO(N, MaxFEs, lb, ub, dim, fobj)

if (max(size(ub)) == 1)
    ub = ub .* ones(1, dim);
    lb = lb .* ones(1, dim);
end

X0 = initialization(N, dim, ub, lb);
X = X0;
Convergence_curve=[];
FEs = 0;
it = 1;

AllFitness = zeros(1, N);
for i = 1:N
    AllFitness(i) = fobj(X(i, :));
end
[AllFitness, index] = sort(AllFitness);
GBestF = AllFitness(1); 
for i = 1:N
    X(i, :) = X0(index(i), :);
end
GBestX = X(1, :);
X_new = X;
FEs = FEs + N;
while FEs<=MaxFEs
    alpha = rand(1) / 5;
    sita = rand(1) * pi;
    preGBestX = GBestX;
    for i = 1:N
        St = randi([1, 4]);
       
        if St == 1
                X_new(i, :) = (X(i, :) - GBestX) .* Levy(1,dim) + rand(1) * mean(X(i, :)) * (1 - FEs / MaxFEs) ^ (2 * FEs / MaxFEs);
     
        elseif St == 2
                X_new(i, :) = X(i, :) + GBestX .* Levy(1,dim) + randn() * (1 - FEs / MaxFEs) * ones(1, dim);
   
        elseif St == 3
                H = rand(1);
                if H < 0.5
                    X_new(i, :) = X(i, :) + alpha * (1 - FEs / MaxFEs) * (X(i, :) - mean(X(i, :)));
                else
                    X_new(i, :) = X(i, :) + alpha * (1 - FEs / MaxFEs) * exp(-FEs / (rand(1) * MaxFEs));
                end
     
        else
                X_new(i, :) = X(i, :) + rand() .* cos((pi *FEs )/ (2 .* MaxFEs)) .* (GBestX - X(i, :)) - cos(sita) .* (FEs / MaxFEs) ^ (2 / MaxFEs) .* (X(i, :) - GBestX);
        end
        
        Flag4ub=X_new(i,:)>ub;
        Flag4lb=X_new(i,:)<lb;
        X_new(i,:)=(X_new(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
        AllFitness(i) = fobj(X_new(i,:));
        X(i,:) = X_new(i,:);
        FEs=FEs+1;
        if AllFitness(i) < GBestF
            GBestF = AllFitness(i);
            GBestX = X_new(i, :);
        end
    end
    [AllFitness, index] = sort(AllFitness); 
    for i = 1:N
        X(i, :) = X(index(i), :);
    end
    %
    Convergence_curve(it)=GBestF;
    it=it+1;
end 
end

function o = Levy(n,d)
beta=1.5;
sigma=(gamma(1+beta).*sin(pi*beta/2)./(gamma((1+beta)/2).*beta.*2.^((beta-1)/2))).^(1/beta);
u=randn(n,d)*sigma;
v=randn(n,d);
step=u./abs(v).^(1/beta);
o=step;
end