function [BestSol,Convergence_curve]=DE( SearchAgents_no,MaxFEs,lb,ub,dim,fobj)

para=[SearchAgents_no,MaxFEs,0.2,0.8,0.2];
nPop=para(1); 
MaxIt=para(2); 
nVar=dim; 
VarSize=[1,dim]; 
beta_min=para(3); 
beta_max=para(4); 
pCR=para(5);
lb=ones(1,dim).*lb;
ub=ones(1,dim).*ub; 
FEs=0;
empty_individual.Position=[]; 
empty_individual.Cost=[]; 
BestSol.Cost=inf;
pop=repmat(empty_individual,nPop,1); 
for i=1:nPop 
    pop(i).Position=init_individual(lb,ub,dim,1);
    pop(i).Cost=fobj(pop(i).Position) ;
    FEs=FEs+1;
    if pop(i).Cost<BestSol.Cost 
        BestSol=pop(i); 
    end    
end
BestCost=zeros(MaxIt,1); 
Convergence_curve=[];
it=1;

while FEs<MaxIt
    for i=1:nPop 
        x=pop(i).Position; 
  
        A=randperm(nPop);
        A(A==i)=[]; 
        a=A(1);
        b=A(2);
        c=A(3);
       
        beta=unifrnd(beta_min,beta_max,VarSize); 
        y=pop(a).Position+beta.*(pop(b).Position-pop(c).Position); 
    
        y=max(y,lb);
		y=min(y,ub);
      
        z=zeros(size(x)); 
        j0=randi([1,numel(x)]); 
        for j=1:numel(x) 
            if j==j0 || rand<=pCR 
                z(j)=y(j); 
            else
                z(j)=x(j); 
            end
        end
        NewSol.Position=z; 
        NewSol.Cost=fobj(NewSol.Position);
        FEs=FEs+1;
        if NewSol.Cost<pop(i).Cost
            pop(i)=NewSol; 
            if pop(i).Cost<BestSol.Cost 
               BestSol=pop(i); 
            end
        end
    end    

    BestCost(it)=BestSol.Cost;  
    Convergence_curve(it)=BestSol.Cost;
    it=it+1;
end
Positionbest=BestSol.Position;
bestCVaccuarcy=BestSol.Cost;
end
function x=init_individual(xlb,xub,dim,sizepop)
xRange=repmat((xub-xlb),[sizepop,1]);
xLower=repmat(xlb,[sizepop,1]);
x=rand(sizepop,dim).*xRange+xLower;
end