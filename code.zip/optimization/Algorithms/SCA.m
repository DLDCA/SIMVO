
function [Destination_position,Convergence_curve]=SCA(N,Max_iteration,lb,ub,dim,fobj)

X=initialization(N,dim,ub,lb);

Destination_position=zeros(1,dim);
Destination_fitness=inf;

Convergence_curve=[];
Objective_values = zeros(1,size(X,1));

FEs=0;
it=1;
for i=1:size(X,1)
    FEs = FEs+1;
    Objective_values(1,i)=fobj(X(i,:));
    if i==1
        Destination_position=X(i,:);
        Destination_fitness=Objective_values(1,i);
    elseif Objective_values(1,i)<Destination_fitness
        Destination_position=X(i,:);
        Destination_fitness=Objective_values(1,i);
    end
    Convergence_curve(it)=Destination_fitness;
end

it=it+1; 
while FEs<Max_iteration
    a = 2;
    r1=a-FEs*((a)/Max_iteration); 
    for i=1:size(X,1) 
        for j=1:size(X,2) 
            r2=(2*pi)*rand();
            r3=2*rand;
            r4=rand();
            
            if r4<0.5
               
                X(i,j)= X(i,j)+(r1*sin(r2)*abs(r3*Destination_position(j)-X(i,j)));
            else
               
                X(i,j)= X(i,j)+(r1*cos(r2)*abs(r3*Destination_position(j)-X(i,j)));
            end

        end
        beta=3/2;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
       s=X(i,:);
  
    u=randn(size(s))*sigma;
    v=randn(size(s));
    step=u./abs(v).^(1/beta);  
    stepsize=0.01*step.*(s-best);
    s=s+stepsize.*randn(size(s));
   X(i,:)=simplebounds(s,lb,ub); 
    end
    
    
    for i=1:size(X,1)
        
        Flag4ub=X(i,:)>ub;
        Flag4lb=X(i,:)<lb;
        X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
        
        FEs = FEs+1;
        Objective_values(1,i)=fobj(X(i,:));
        
        if Objective_values(1,i)<Destination_fitness
            Destination_position=X(i,:);
            Destination_fitness=Objective_values(1,i);
        end
    end
    
    Convergence_curve(it)=Destination_fitness;
    it=it+1;
end

end
