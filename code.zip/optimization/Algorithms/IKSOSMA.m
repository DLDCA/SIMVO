function [Destination_fitness, Convergence_curve]=IKSOSMA(N,Max_iter,lb,ub,dim,fobj)

X=initialization(N,dim,ub,lb);
a=zeros(1,dim);
tmpxx=zeros(1,dim);
weight = ones(N,dim);
Destination_fitness=inf;
bestPositions = ones(1,dim);

FEs=0;
it=1;
jingdu=1e-3;

while  FEs < Max_iter

    for i=1:N
        AllFitness(i) = fobj(X(i,:));
        FEs=FEs+1;
    end
    [SmellOrder,SmellIndex] = sort(AllFitness);  
    worstFitness = SmellOrder(N);
    bestFitness = SmellOrder(1);
    S=bestFitness-worstFitness+eps;  
    if bestFitness < Destination_fitness
        bestPositions=X(SmellIndex(1),:);
        Destination_fitness=bestFitness;
    end
    for i=1:N
        for j=1:dim
            if i<=(N/2) 
                weight(SmellIndex(i),j) = 1+rand()*log10((bestFitness-SmellOrder(i))/(S)+1);
            else
                weight(SmellIndex(i),j) = 1-rand()*log10((bestFitness-SmellOrder(i))/(S)+1);
            end
        end
    end
    aa = atanh(-(FEs/Max_iter)+1); 
    for i=1:N
        vb = unifrnd(-aa,aa,1,dim);
        F_i = fobj(X(i,:)); 
        FEs = FEs+1;
        x=[];
        for j=1:dim
            tmpxx=X(i,:);
            if rand<0.1     
                tmpxx(j)=lb+rand()*(ub-lb);
            else    
            A = randi([1,N]);  
            B = randi([1,N]);
            tmpxx(j) = bestPositions(j)+ vb(j)*(weight(i,j)*X(A,j)-X(B,j));
            end
             x=[x;tmpxx];    
        end

        for ii=1:dim
            Flag4ub=x(ii,:)>ub;
            Flag4lb=x(ii,:)<lb;
            x(ii,:)=(x(ii,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
            x_All_Fitness(ii) = fobj(x(ii,:));
            FEs = FEs+1;
        end

        d=unidrnd(dim);
        xx=initialization(1,dim,ub,lb);
        temp=xx(d);
        xx=X(i,:);
        xx(d)=temp;
        xx_fitness=fobj(xx);
        FEs=FEs+1;

        All_X=[X(i,:);x;xx];
        All_fitness=[F_i x_All_Fitness xx_fitness];
        
        [min_fitness, index]=min(All_fitness);
        max_All_fitness =max(All_fitness);
        if min_fitness < Destination_fitness 
            Destination_fitness = min_fitness;
            bestPositions = All_X(index,:);
        end

        All_fitness=(exp(1)-1)*(All_fitness-min_fitness)/(max_All_fitness-min_fitness+eps)+1;
        sigma=(xx(d)-x(d,d))/(log(All_fitness(1)/All_fitness(dim+2))/(X(i,d)-xx(d)+eps)-log(All_fitness(1)/All_fitness(d+1))/(X(i,d)-x(d,d)+eps)+eps);
   
        for j=1:dim
            a(j)=-sigma*log(All_fitness(1)/All_fitness(j+1))/(X(i,j)-x(j,j)+eps)+X(i,j)+x(j,j);
            a(j)=a(j)/2;
            if sigma<0
                if(a(j)>=(ub+lb)/2) 
                    a(j)=lb;
                else
                a(j)=ub;
                end
            else
                if(a(j)<lb)
                    a(j)=lb;
                else
                    if(a(j)>ub)
                        a(j)=ub;
                    end
                end
            end
        end
        F_a = fobj(a);
        FEs=FEs+1;
        if F_a<= Destination_fitness 
           X(i,:) = a;
           Destination_fitness = F_a;
           bestPositions = a;
        else
           X(i,:)=bestPositions+(a-bestPositions).*rand(1,dim)*exp(FEs*log(jingdu)/(Max_iter)); 
        end
    Flag4ub=X(i,:)>ub;
    Flag4lb=X(i,:)<lb;
    X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
    end
    Convergence_curve(it)=Destination_fitness;
    it=it+1;
end
end