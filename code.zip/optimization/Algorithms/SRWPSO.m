
function [bestPos,cg_curve]=SRWPSO(N,MaxFEs,lb,ub,dim,fobj)

Vmax=6;
noP=N;
wMax=0.9;
wMin=0.2;
c1=2;
c2=2;

vel=zeros(noP,dim);
pBestScore=zeros(noP);
pBest=zeros(noP,dim);
gBest=zeros(1,dim);
cg_curve=[];

p = sobolset(dim);
pos = [];
for i=1:N
    r=p(i,:);
    r=lb+r.*(ub-lb);
    pos=[pos;r];
end
for i=1:noP
    pBestScore(i)=inf;
end

gBestScore=inf;
it=1;
FEs=0;
s=0.01;  

for i=1:size(pos,1)
   
    Flag4ub=pos(i,:)>ub;
    Flag4lb=pos(i,:)<lb;
    pos(i,:)=(pos(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
    
    FEs=FEs+1;
    fitness1=fobj(pos(i,:));
    if(pBestScore(i)>fitness1)
        pBestScore(i)=fitness1;   
        pBest(i,:)=pos(i,:);
     
    end
    if(gBestScore>fitness1)  
        gBestScore=fitness1;
        gBest=pos(i,:);
    end
end

while  FEs < MaxFEs
    
    for i=1:size(pos,1)
        M=pBest(i,:);
      
        for h=1:size(pos,2)
            if(tan(pi*(rand-0.5))>(1-FEs/MaxFEs))  
                M(h)= gBest(h);               
            end
        end
        Fitnessm=fobj(M);              
        FEs=FEs+1;
        if(pBestScore(i)>Fitnessm)
            pBestScore(i)=Fitnessm;  
            pBest(i,:)=M;
        end
        if (Fitnessm<gBestScore)
            gBestScore = Fitnessm;
            gBest =M;
           
        end

    end
   
    for i=1:size(pos,1)
       
        w=(1-FEs/MaxFEs)^(1-tan(pi*(rand-0.5))*s/MaxFEs);  
        
        for j=1:size(pos,2)
            vel(i,j)=w*vel(i,j)+c1*rand()*(pBest(i,j)-pos(i,j))+c2*rand()*(gBest(j)-pos(i,j));
           
            if(vel(i,j)>Vmax)
                vel(i,j)=Vmax;
            end
            if(vel(i,j)<-Vmax)
                vel(i,j)=-Vmax;
            end
            
            pos(i,j)=pos(i,j)+vel(i,j);
        end 
    end
   
    for i=1:size(pos,1)
        
        Flag4ub=pos(i,:)>ub;
        Flag4lb=pos(i,:)<lb;
        pos(i,:)=(pos(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
    
        FEs=FEs+1;
        fitness=fobj(pos(i,:));
        if(pBestScore(i)>fitness)
            pBestScore(i)=fitness;
            pBest(i,:)=pos(i,:);
        end
        if(gBestScore>fitness)
            gBestScore=fitness;
            gBest=pos(i,:);
            
            s=s/2;         
        end
        s=s+1;
    end
    
    cg_curve(it)=gBestScore;
    it=it+1;
    bestPos=gBest;
end

end