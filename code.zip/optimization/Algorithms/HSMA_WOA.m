
function [bestPositions,Convergence_curve] = HSMA_WOA(N,Max_FEs,lb,ub,dim,fobj)


bestPositions=zeros(1,dim);
Destination_fitness=inf;
AllFitness = inf*ones(N,1);
weight = ones(N,dim);
X=initialization(N,dim,ub,lb);
Convergence_curve=[];
FEs=0;   
MaxFEs=Max_FEs;  
fitcount = 1;
CI=12000;  
lb=ones(1,dim).*lb; 
ub=ones(1,dim).*ub; 
z=0.03; 
while  FEs < MaxFEs

    if FEs<CI
        
        X=WOA_S(N,X,bestPositions,FEs,MaxFEs);
       
        for i=1:N
           
            Flag4ub=X(i,:)>ub;
            Flag4lb=X(i,:)<lb;
            X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
            AllFitness(i) = fobj(X(i,:));
            FEs = FEs+1;
            if AllFitness(i) < Destination_fitness
                Destination_fitness = AllFitness(i);
                bestPositions = X(i,:);
            end
        end
    end  

    [SmellOrder,SmellIndex] = sort(AllFitness); 
    worstFitness = SmellOrder(N);
    bestFitness = SmellOrder(1);

    S=bestFitness-worstFitness+eps;  
    for i=1:N
        for j=1:dim
            if i<=(N/2)    
                weight(SmellIndex(i),j) = 1+rand()*log10((bestFitness-SmellOrder(i))/(S)+1);
            else
                weight(SmellIndex(i),j) = 1-rand()*log10((bestFitness-SmellOrder(i))/(S)+1);
            end
        end
    end
    
    if bestFitness < Destination_fitness
        bestPositions=X(SmellIndex(1),:);
        Destination_fitness = bestFitness;
    end
    
    a = atanh(-(FEs/Max_FEs)+1); 
    b = 1-FEs/Max_FEs; 
  
    for i=1:N
        if rand<z    
            X(i,:) = (ub-lb)*rand+lb;
        else
            p =tanh(abs(AllFitness(i)-Destination_fitness));
            vb = unifrnd(-a,a,1,dim); 
            vc = unifrnd(-b,b,1,dim);
            for j=1:dim
                r = rand();
                A = randi([1,N]);    
                B = randi([1,N]);
                if r<p        
                    X(i,j) = bestPositions(j)+ vb(j)*(weight(i,j)*X(A,j)-X(B,j));
                else
                    X(i,j) = vc(j)*X(i,j);
                end
            end
        end
    end
 
 
    for i=1:N
      
        Flag4ub=X(i,:)>ub;
        Flag4lb=X(i,:)<lb;
        X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
        AllFitness(i) = fobj(X(i,:));
        FEs = FEs+1;
        if AllFitness(i) < Destination_fitness 
            Destination_fitness = AllFitness(i);
            bestPositions = X(i,:);
        end
    end    
    Convergence_curve(1,fitcount) = Destination_fitness;
    fitcount = fitcount + 1;
end

end

function X=WOA_S(N,X,bestPositions,FEs,MaxFEs)
    
    a=2-FEs*((2)/MaxFEs); 
    a2=-1+FEs*((-1)/MaxFEs);
    
    for i=1:size(X,1)
        r1=rand(); 
        r2=rand();
        
        A=2*a*r1-a; 
        C=2*r2;    
        
        
        b=1;             
        l=(a2-1)*rand+1; 
        
        p = rand(); 
        
        for j=1:size(X,2)
            
            if p<0.5   
                if abs(A)>=1
                    rand_leader_index = floor(N*rand()+1);
                    X_rand = X(rand_leader_index, :);
                    D_X_rand=abs(C*X_rand(j)-X(i,j)); 
                    X(i,j)=X_rand(j)-A*D_X_rand;     
                    
                elseif abs(A)<1
                    D_Leader=abs(C*bestPositions(j)-X(i,j)); 
                    	X(i,j)=bestPositions(j)-A*D_Leader;    
                end
                
            elseif p>=0.5
              
                distance2Leader=abs(bestPositions(j)-X(i,j));

                X(i,j)=distance2Leader*exp(b.*l).*cos(l.*2*pi)+bestPositions(j);
                
            end
            
        end
        
    end
end
