function [GBEST,cg_curve]=SFLA(N,T,lb,ub,dim,fobj)

fbest = inf;

GBEST = zeros(1,dim);
it=0;
FEs = 0;
if (size(ub, 2)~=1)
    dim = size(ub, 2);
else
    lb = lb*ones(1,dim);
    ub = ub*ones(1,dim);
end

nVar=dim;
VarSize = [1 nVar];     
VarMin=lb;
VarMax=ub;

cg_curve = [];
nPopMemeplex = 10;                         
nMemeplex = 5;                 
nPopMemeplex = N / nMemeplex;   
nPop = nMemeplex*nPopMemeplex;	

I = reshape(1:N, nMemeplex, []);

fla_params.q = max(round(0.3*nPopMemeplex),2); 
fla_params.alpha = nPopMemeplex;
fla_params.beta = 5;   
fla_params.sigma = 2;  
fla_params.VarMin = VarMin;
fla_params.VarMax = VarMax;

empty_individual.Position = [];
empty_individual.Cost = [];


pop = repmat(empty_individual, nPop, 1);

for i=1:nPop

    pop(i).Position = rand(1,dim).*(ub-lb)+lb;
    pop(i).Cost = fobj(pop(i).Position);
    FEs = FEs + 1;
    if pop(i).Cost < fbest
        fbest = pop(i).Cost;
        GBEST = pop(i).Position;
    end
end

pop = SortPopulation(pop);

BestSol = pop(1);
BestCosts=[];
while FEs < T
    
    fla_params.BestSol = BestSol;

    Memeplex = cell(nMemeplex, 1);
    
    for j = 1:nMemeplex
     
        Memeplex{j} = pop(I(j,:));
       
        [Memeplex{j},BestSol, FEs] = RunFLA_FEs(Memeplex{j}, fla_params,fobj, FEs);
        pop(I(j,:)) = Memeplex{j};
        fla_params.BestSol = BestSol;
    end

    pop = SortPopulation(pop);
    
    BestSol = pop(1);
    
    fbest = BestSol.Cost;
    GBEST = BestSol.Position;

    it = it + 1;
    cg_curve(it) = fbest;
end

end

function [pop, SortOrder] = SortPopulation(pop)

    Costs = [pop.Cost];
    
    [~, SortOrder]=sort(Costs);
    
    pop = pop(SortOrder);

end

function [pop,BestSol, FEs] = RunFLA_FEs(pop, params,fobj, FEs)

    q = params.q;          
    alpha = params.alpha;   
    beta = params.beta;     
    sigma = params.sigma;
    VarMin = params.VarMin;
    VarMax = params.VarMax;
    VarSize = size(pop(1).Position);
    BestSol = params.BestSol;
    
    nPop = numel(pop);      
    P = 2*(nPop+1-(1:nPop))/(nPop*(nPop+1));   
    LowerBound = pop(1).Position;
    UpperBound = pop(1).Position;
    for i = 2:nPop
        LowerBound = min(LowerBound, pop(i).Position);
        UpperBound = max(UpperBound, pop(i).Position);
    end
    
    for it = 1:beta
       
        L = RandSample(P,q);
        B = pop(L);
      
        for k=1:alpha
           
            [B, SortOrder] = SortPopulation(B);
            L = L(SortOrder);
            
            ImprovementStep2 = false;
            Censorship = false;
            
            NewSol1 = B(end);
            Step = sigma*rand(VarSize).*(B(1).Position-B(end).Position);
            NewSol1.Position = B(end).Position + Step;
            if IsInRange(NewSol1.Position, VarMin, VarMax)
                NewSol1.Cost = fobj(NewSol1.Position);
                FEs = FEs + 1;
                if NewSol1.Cost < BestSol.Cost
                    BestSol.Cost = NewSol1.Cost;
                    BestSol.Position = NewSol1.Position;
                end
                if NewSol1.Cost<B(end).Cost
                    B(end) = NewSol1;
                else
                    ImprovementStep2 = true;
                end
            else
                ImprovementStep2 = true;
            end
            
            if ImprovementStep2
                NewSol2 = B(end);
                Step = sigma*rand(VarSize).*(BestSol.Position-B(end).Position);
                NewSol2.Position = B(end).Position + Step;
                if IsInRange(NewSol2.Position, VarMin, VarMax)
                    NewSol2.Cost = fobj(NewSol2.Position); 
                    FEs = FEs + 1;
                    if NewSol2.Cost < BestSol.Cost
                        BestSol.Cost = NewSol2.Cost;
                        BestSol.Position = NewSol1.Position;
                    end
                    if NewSol2.Cost<B(end).Cost
                        B(end) = NewSol2;
                    else
                        Censorship = true;
                    end
                else
                    Censorship = true;
                end
            end
             
            if Censorship
                B(end).Position = unifrnd(LowerBound, UpperBound);
                B(end).Cost = fobj(B(end).Position); 
                FEs = FEs + 1;
                if B(end).Cost < BestSol.Cost
                    BestSol.Cost = B(end).Cost;
                    BestSol.Poaition = B(end).Position;
                end

            end
        end
        pop(L) = B;
        
    end
    
end

function L = RandSample(P, q, replacement)

    if ~exist('replacement','var')
        replacement = false;
    end

    L = zeros(q,1);
    for i=1:q
        L(i) = randsample(numel(P), 1, true, P);
        if ~replacement
            P(L(i)) = 0;
        end
    end

end

function b = IsInRange(x, VarMin, VarMax)

    b = all(x>=VarMin) && all(x<=VarMax);

end