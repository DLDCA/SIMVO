function [Leader_pos,Convergence_curve]=ACO(SearchAgents_no,MaxFEs,lb,ub,dim,fobj)

FEs=0;
it=1;
k=9;           
m=SearchAgents_no;             
q=0.6;
ibslo=1;     
X_Fitness = inf*ones(k,1);
Convergence_curve=[];
bestPositions=zeros(1,dim);

X=initialization(k,dim,ub,lb);
for i=1:k
    X_Fitness(i)=fobj(X(i,:));
	FEs=FEs+1;    
end

[~, SortOrder]=sort(X_Fitness);
X=X(SortOrder,:);
bestPositions=X(1,:);                  
w=1/(sqrt(2*pi)*q*k)*exp(-0.5*(((1:k)-1)/(q*k)).^2);           
p_g=w/sum(w);              

     while FEs<=MaxFEs   

        s=zeros(k,dim);
        for l=1:k
            s(l,:)=X(l,:);
        end  

        Newpop=zeros(m,dim);
        Newpop_fitness=inf*ones(m,1);
        for t=1:m     

            for i=1:dim 

                for j=1:k
                    if p_g(j)>=rand
                          l=j;
                          break;
                    end
                end     

                D=0;
                for r=1:k
                    D=D+abs(s(l,i)-s(r,i));
                end
                sigma=ibslo*D/(k-1);           

                Newpop(t,i)=s(l,i)+sigma*randn;
            end

            Flag4ub=Newpop(t,:)>ub;
            Flag4lb=Newpop(t,:)<lb;
            Newpop(t,:)=(Newpop(t,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
            % Evaluation
            Newpop_fitness(t)=fobj(Newpop(t,:)); 
            FEs=FEs+1;
        end    

        All_X=[X;Newpop];
        All_X_fitness=[X_Fitness;Newpop_fitness];

        [All_X_fitnessed, SortOrder]=sort(All_X_fitness);
        All_X=All_X(SortOrder,:);

        X=All_X(1:k,:);
        X_Fitness=All_X_fitnessed(1:k);
        %%

        bestPositions=X(1,:);
        bestFitness=All_X_fitnessed(1);

        Convergence_curve(it)=bestFitness;
        Leader_pos=bestPositions;

        it=it+1;
     end
end
