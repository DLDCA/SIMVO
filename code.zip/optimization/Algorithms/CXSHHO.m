
function [Rabbit_Location, CNVG]=CXSHHO(N,MaxFEs,lb,ub,dim,fobj)

tic

Rabbit_Location=zeros(1,dim);
Rabbit_Energy=inf;


X=initialization(N,dim,ub,lb);
Lb=lb.*ones(1,dim);
Ub=ub.*ones(1,dim);
CNVG=[];
FEs=0;
W=5;
t=0; 

while FEs<MaxFEs
    for i=1:size(X,1)
       
        FU=X(i,:)>ub;FL=X(i,:)<lb;X(i,:)=(X(i,:).*(~(FU+FL)))+ub.*FU+lb.*FL;
       
        fitness(i)=fobj(X(i,:));
        FEs=FEs+1;
       
        if fitness(i)<Rabbit_Energy
            Rabbit_Energy=fitness(i);
            Rabbit_Location=X(i,:);
        end
    end

    for j=1 : dim
        EG=X(:,j);    
        EG=sort(EG);
        i=round(rand()*(size(X,1))+0.5);  
        if rand()< FEs/MaxFEs
            X(i,:)=Rabbit_Location;
        end
        r=rand();
        X(i,j)=r*X(i,j)+(1-r)*(EG(1)+EG(2))/2; 
    end
    
    c=2*(1-(FEs/MaxFEs)); 
    for i=1:size(X,1)
        
        Escaping_Energy=c*(2*rand()-1); 
        
        if abs(Escaping_Energy)>=1
            
            q=rand();
            rand_Hawk_index = floor(N*rand()+1);
            X_rand = X(rand_Hawk_index, :);
            if q<0.5
                
                X(i,:)=(X_rand-(rand*abs(X_rand-2*rand*X(i,:))));
            elseif q>0.5
              
                X(i,:)=((((Rabbit_Location(1,:)-mean(X)))-(rand*((ub-lb)*rand+lb))));
            end
        elseif abs(Escaping_Energy)<1
        
            r=rand;
            if abs(Escaping_Energy)<0.5 && r>=0.5
              
                X(i,:)=(Rabbit_Location)-Escaping_Energy*abs(Rabbit_Location-X(i,:));
            end
            if abs(Escaping_Energy)>0.5 && r>=0.5
             
                Jump_strength=2*(1-rand()); 
                X(i,:)=(Rabbit_Location-X(i,:))-Escaping_Energy*abs(Jump_strength*Rabbit_Location-X(i,:));
            end
         
        end
    
        Flag4ub=X(i,:)>ub;
        Flag4lb=X(i,:)<lb;
        X(i,:)=(X(i,:).*(~(Flag4ub+Flag4lb)))+ub.*Flag4ub+lb.*Flag4lb;
        fitness(i)=fobj(X(i,:));
        FEs=FEs+1;
        num=floor(rand*N+1);
        num2=floor(rand*N+1);
        [newP1,newP2]=DX(Rabbit_Location,X(num,:),X(num2,:),lb,ub);
        FEs=FEs+2;
        h1=fobj(newP1);
        h2=fobj(newP2);
        if h1< fitness(i)
            X(i,:)=newP1;
            fitness(i)=h1;
        end
        if h2< fitness(i)
            X(i,:)=newP2;
            fitness(i)=h2;
        end
        if fitness(i)<Rabbit_Energy 
            Rabbit_Energy=fitness(i); 
            Rabbit_Location=X(i,:);
        end
    end
    RimeFactor = (rand-0.5)*2*cos((pi*FEs/(MaxFEs/10)))*(1-round(FEs*W/MaxFEs)/W);
    normalized_rime_rates=normr(fitness);
    E=sqrt(FEs/MaxFEs);
    for i=1:N
        for j=1:dim
          
            r1=rand();
            if r1< E
                X(i,j)=Rabbit_Location(1,j)+RimeFactor*((Ub(j)-Lb(j))*rand+Lb(j));
            end
        end
    end
    t=t+1;
    CNVG(t)=Rabbit_Energy;
 
end
toc
end

function o=Levy(d)
beta=1.5;
sigma=(gamma(1+beta)*sin(pi*beta/2)/(gamma((1+beta)/2)*beta*2^((beta-1)/2)))^(1/beta);
u=randn(1,d)*sigma;v=randn(1,d);step=u./abs(v).^(1/beta);
o=step;
end